@extends('layouts/main')  
@section('content')  
{{$request}} 
{{$JoeSearch}}   
{{$serps}}  
{{$body}}  
{{$processsite}} 
{{$sites}} 
{{$searchTerms}}  
 @endsection 

