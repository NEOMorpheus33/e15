@section('footer')
<footer> 
    &copy; 2021 Copyright Joseph Paul Fanning of Harvard University  
</footer> 
@endsection 