         
<?php $__env->startSection('Search'); ?> 

<nav> 
    <ul>
        <!-- nav links  -->

        <li> 
            <?php if(!Auth::user()): ?>
                <a href='/login'>Login</a>
            <?php else: ?>
                <form method='POST' id='logout' action='/logout'>
                    <?php echo e(csrf_field()); ?>

                    <a href='#' onClick='document.getElementById("logout").submit();'>Logout</a>
                </form>
            <?php endif; ?>
        </li>
    </ul>
</nav> 

<?php if(Auth::user()): ?>
<h2>
    Hello <?php echo e(Auth::user()->name); ?>!
</h2>
<?php endif; ?>

<table> 
  
 <form action="/process" method="GET">     

  <tr><td><input type="text" name="JoeSearch" value=" "> </td></tr>   
  <tr><td><label for="text">Type Keywords Search</label></td></tr> 
  
  <tr><td><input type="checkbox" name="PublicSearch" value="already_crawled"> </td></tr>  
  <tr><td><label for="PublicSearch">  Public Search </label></td> </tr>  

  <tr><td><input type="checkbox" name="PrivateSearch" value="already_crawled"> </td></tr> 
  <tr><td><label for="PublicSearch">  Private Search </label></td> </tr>         

</table>  

<table> 
<tr><th>I am an</th></tr> 
<tr><td><input type="radio" name="adult" value="$adult">An adult </td></tr>
<tr><td><input type="radio" name="adult" value="minor">A minor </td></tr>
  
<tr><td> <input type="submit" value="Answer"> </td></tr> 
</form> 
</table>   

<h1>Search Engine Results</h1> 
<?php if($serps): ?> 

    <table border=1>
        <tr><td><?php echo e($serps->title); ?> </td></td>  
        <tr><td><?php echo e($serps->description); ?> </td></tr> 
        <tr><td><?php echo e($serps->body); ?> </td></tr>   
    </table> 

<?php endif; ?>

<?php if(count($errors) > 0): ?>
    <ul class='Request'>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul> 
<?php endif; ?> 

<?php $__env->stopSection(); ?>      





 






<?php echo $__env->make('layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/e15/p3/resources/views/index.blade.php ENDPATH**/ ?>