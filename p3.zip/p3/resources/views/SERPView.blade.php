@extends('main') 
@section('SERPSView') 

<!-- View stored in resources/views/SERPSView.blade.php --> 

<html>
    <body>
        <h1>Results {{ $details }}</h1> 
    </body>
</html> 









