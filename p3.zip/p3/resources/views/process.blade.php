@extends('main') 
@section('content') 
{{$request}}
{{$JoeSearch}} 
 @endsection 

