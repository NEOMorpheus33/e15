<html>    
<body>    


Search Results here: <?php echo $_GET["JSearch"]; ?>    

</body>     
</html>     





