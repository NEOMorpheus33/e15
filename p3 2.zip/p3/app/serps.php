<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Serps extends Controller
{
    public function serps($serps)
    {
        $serps = new Serp;
    
        $serps->url=     // $serps
                     // ($errps) = ($serps) = <id>
$title->title = "";
        echo $title->$title."\n";

        $url->url = "";
        echo $url->$url."\n";

        $dsescription->description = "";
        echo $descriptoin>$description."\n";
    }
}
