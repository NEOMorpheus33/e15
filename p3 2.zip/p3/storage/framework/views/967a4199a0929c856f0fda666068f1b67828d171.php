<?php $__env->startSection('content'); ?>

<h1>Login</h1>

Don’t have a JSearch account? <a href='/register'>Register for JSeaerch here.</a>

<form method='POST' action='/login'>

    <?php echo e(csrf_field()); ?>


    <label for='email'>E-Mail Address</label>
    <input id='email' type='email' name='email' value='<?php echo e(old('email')); ?>' autofocus>
    <?php echo $__env->make('includes.error-field', ['fieldName' => 'email'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <label for='password'>Password</label>
    <input id='password' type='password' name='password'>
    <?php echo $__env->make('includes.error-field', ['fieldName' => 'password'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <label>
        <input type='checkbox' name='remember' <?php echo e(old('remember') ? 'checked' : ''); ?>> Remember Me
    </label>

    <button type='submit' class='btn btn-primary'>Login</button>

    </a>

</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/e15/p3/resources/views/auth/login.blade.php ENDPATH**/ ?>