   


<h1>Add a book</h1>

<p>Add a Website Here for Quiker Indexing</p> 

<form method='POST' action='/CRUD/JoeSearch.php'>
    <div class='details'>* Required fields</div>
    <?php echo e(csrf_field()); ?>


    <label for='title'>* Title</label>
    <input type='text' name='title' id='title' value='<?php echo e(old("title")); ?>'> 
    <?php echo $__env->make('includes/error-field', ['fieldName' => 'title'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <label for='url'>* Site Url</label>
    <div class='details'>
        This is a unique URL identifier for the book, containing only alphanumeric characters and dashes.
        <br>It’s suggested that the slug be based on the book title, e.g. a good slug for the book <em>“War and Peace”</em> would be <em>“war-and-peace”</em>.
    </div>
    <input type='text' name='JoeSearch' id='url' value='<?php echo e(old("url")); ?>'>
    <?php echo $__env->make('includes/error-field', ['fieldName' => 'url'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 

    <label for='description'>* descripton</label> 
    <input type='text' name='JoeSearch' id='description' value='<?php echo e(old("description")); ?>'>
    <?php echo $__env->make('includes/error-field', ['fieldName' => 'author'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <label for='body'>* Body content (YYYY)</label>
    <input type='text' name='JoeSearch' id='body' value='<?php echo e(old("body")); ?>'>
    <?php echo $__env->make('includes/error-field', ['fieldName' => 'published_year'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <button type='submit' class='btn btn-primary'>Add My Site</button>

    <?php if(count($errors) > 0): ?>
    <div class='alert alert-danger'>
        Please correct the above errors.
    </div>
    <?php endif; ?>

</form>


<?php echo $__env->make('layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/e15/p3/resources/views//CRUD/create.blade.php ENDPATH**/ ?>