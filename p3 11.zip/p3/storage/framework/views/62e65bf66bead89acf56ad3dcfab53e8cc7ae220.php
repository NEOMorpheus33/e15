<!Doctype html>     
<html lang='en'>   
<head> 
    
    <title> <?php echo $__env->yieldContent('title'); ?> </title>  
    <meta charset='utf-8'> 
    <link href='style.css' rel='stylesheet'> 

    <?php echo $__env->yieldContent('head'); ?> 
</head>    

<body>  

 <h1>Joe's Harvard Best Search Engine CSCI-E15 Buck</h1>   
    
    
    <?php echo $__env->yieldContent('content'); ?> 
    <?php echo $__env->yieldContent('Search'); ?> 
    <?php echo $__env->yieldContent('crawled'); ?> 
    <?php echo $__env->yieldContent('addsite'); ?> 

    <footer> 
    <?php echo $__env->yieldContent('footer'); ?>
    <p> <span style='font-size:30px;'>&#9752;</span> Copyright 2021 | Joseph P. Fitzgerald Fanning JPFF | Dr. Buck | Harvard University <span style='font-size:30px;'>&#9752;</span></P>
    </footer>   
</body> 
    
</html>   




<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/e15/p3/resources/views/layouts/main.blade.php ENDPATH**/ ?>