<!Doctype html>     
<html lang='en'>   
<head> 
    
    <title> @yield('title') </title>  
    <meta charset='utf-8'> 
    <link href='style.css' rel='stylesheet'> 

    @yield('head') 
</head>    

<body>  

 <h1>Joe's Harvard Best Search Engine CSCI-E15 Buck</h1>   
    
    
    @yield('content') 
    @yield('Search') 
    @yield ('crawled') 
    @yield('addsite') 

    <footer> 
    @yield('footer')
    <p> <span style='font-size:30px;'>&#9752;</span> Copyright 2021 | Joseph P. Fitzgerald Fanning JPFF | Dr. Buck | Harvard University <span style='font-size:30px;'>&#9752;</span></P>
    </footer>   
</body> 
    
</html>   




