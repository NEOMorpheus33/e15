@extends('layouts/main') 
@section('footer') 

<html>

<body> 

   <p> Copyright  2021 | Joseph P. Fitzgerld Fanning JPFF | Dr. Buck | Harvard University </P>  
 
 </body> 
 
 </html> 
@endsection 

