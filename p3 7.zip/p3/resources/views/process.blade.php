@extends('layouts/main')    
@section('content')  
{{$request}} 
{{$JoeSearch}}   
{{$serps}}  
{{$body}}  
{{$processite}}  
{{$sites}} 
{{$PrivateSearch}} 
{{$list}}  
 @endsection 

