<p>
    <span style='font-size:30px;'>&#9752; </span> Copyright 2021 |
    <a href="https://www.joepfanning.com">Joseph P. Fitzgerald Fanning</a> | JPFF | Dr. Buck |
    <a href="https://www.harvard.edu"> Harvard University App Engineers HES</a>
    <span style='font-size:30px;'>&#9752;</span>
</p>
