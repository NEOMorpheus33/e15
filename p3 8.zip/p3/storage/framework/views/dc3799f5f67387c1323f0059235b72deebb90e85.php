<?php $__env->startSection('Search'); ?>

<nav>
    <ul>
        <!-- nav links  -->

        <li>
            <?php if(!Auth::user()): ?>
            <a href='/login'>Login</a>
            <?php else: ?>
            <form method='POST' id='logout' action='/logout'>
                <?php echo e(csrf_field()); ?>

                <a href='#' onClick='document.getElementById("logout").submit();'>Logout</a>
                | <a href='/CRUD/create'>Add Site</a>
                | <a href='/create'>JSearch Developer Blog</a>
            </form>
            <?php endif; ?>

        </li>
    </ul>
</nav>

<?php if(Auth::user()): ?>
<h2>
    Hello <?php echo e(Auth::user()->name); ?>!
</h2>
<?php endif; ?>

<?php $__env->startSection('content'); ?>

<h1><a href='/register'>register</a> </h1>
<table>

    <form action="/process" method="GET">

        <tr>
            <td>$browser-><input type="text" ([ name="JoeSearch" ] value=" " )>;</td>
            //<input type="text" name="JoeSearch" value=" ">
        </tr>
        <tr>
            <td><label for="text" dusk="KeywordsSearch">Type Keywords Search</label></td>
        </tr>
        <tr>
            <td>
            <td>$browser-><input type="checkbox" ([ name="PrivateSearch" ] value=" " )>;</td>
            </td>
        </tr>

</table>

<h2>Search Engine Results</h2>

<form method="post" action='/sites'>

    title: <input type="text" name="title">
    descripton: <input type="text" name="description">

</form>


<table>

    <th> Your Site Info Here </th>

    

    

</table>

<?php echo $__env->make('layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/e15/p3/resources/views/index.blade.php ENDPATH**/ ?>