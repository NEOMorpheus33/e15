 

<?php $__env->startSection('content'); ?>

<h1>Register</h1>

Already have a JSearch account? <a href='/login'>Login here...</a>

<form method='POST' action='/register'>
    <?php echo e(csrf_field()); ?>


    <label for='name'>Name</label>
    <input id='name' type='text' name='name' value='<?php echo e(old('name')); ?>' autofocus>
    <?php echo $__env->make('includes.error-field', ['fieldName' => 'name'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <label for='email'>E-Mail Address</label>
    <input id='email' type='email' name='email' value='<?php echo e(old('email')); ?>'>
    <?php echo $__env->make('includes.error-field', ['fieldName' => 'email'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <label for='password'>Password (min: 8)</label>
    <input id='password' type='password' name='password'>
    <?php echo $__env->make('includes.error-field', ['fieldName' => 'password'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <label for='password-confirm'>Confirm Password</label>
    <input id='password-confirm' type='password' name='password_confirmation'>

    <button type='submit' class='btn btn-primary'>Register</button>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/e15/p3/resources/views/auth/register.blade.php ENDPATH**/ ?>