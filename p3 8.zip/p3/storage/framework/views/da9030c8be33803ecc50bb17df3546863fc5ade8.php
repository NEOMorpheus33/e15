<?php if($errors->get($fieldName)): ?>
<div class='alert alert-danger error'><?php echo e($errors->first($fieldName)); ?></div>
<?php endif; ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/e15/p3/resources/views/includes/error-field.blade.php ENDPATH**/ ?>