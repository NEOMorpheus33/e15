
# substr('longText');   
# int|100; 
# Return part of a string (above)
# Return part of a string   
# substr(string , int ) [,<int:100> $length:100]; 
 <?php   

# function takes_array($input)
# { 
# echo "$input[0] + $input[1] = ", $input[0]+$input[1];
# } 
# Example #2 Function Argument List with trailing Comma

#function (    
    #subsstr $body, int $start) {string;  
        
        #<?php

        substr($input)
{
   
}


   

// This trailing comma was not permitted before 8.0.0.
    #Return part of a string
    #substr( string $string , int $start [, int $length ]): string
    



 



