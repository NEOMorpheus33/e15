{{-- /resources/views/create.blade.php --}} 
@extends('layouts/main')

@section('title')
Add a website 
@endsection

@section('addsite') 

<h1>Add a book</h1>

<p>Add a Website Here for Quiker Indexing</p> 

<form method='POST' action='/create.php'>
    <div class='details'>* Required fields</div>
    {{ csrf_field() }}

    <label for='title'>* Title</label>
    <input type='text' name='title' id='title' value='{{ old("title") }}'> 
    @include('includes/error-field', ['fieldName' => 'title'])

    <label for='url'>* Site Url</label>
    <div class='details'>
        This is a unique URL identifier for the book, containing only alphanumeric characters and dashes.
        <br>It’s suggested that the slug be based on the book title, e.g. a good slug for the book <em>“War and Peace”</em> would be <em>“war-and-peace”</em>.
    </div>
    <input type='text' name='JoeSearch' id='url' value='{{ old("url") }}'>
    @include('includes/error-field', ['fieldName' => 'url']) 

    <label for='description'>* descripton</label> 
    <input type='text' name='JoeSearch' id='description' value='{{ old("description") }}'>
    @include('includes/error-field', ['fieldName' => 'author'])

    <label for='body'>* Body content (YYYY)</label>
    <input type='text' name='JoeSearch' id='body' value='{{ old("body") }}'>
    @include('includes/error-field', ['fieldName' => 'published_year'])

    <button type='submit' class='btn btn-primary'>Add My Site</button>

    @if(count($errors) > 0)
    <div class='alert alert-danger'>
        Please correct the above errors.
    </div>
    @endif

</form>
@endsection
