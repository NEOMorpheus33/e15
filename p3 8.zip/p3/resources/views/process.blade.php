@extends('layouts/main') 
@section('content') 
{{$request}}
{{$JoeSearch}} 
 @endsection 

