@extends ('main/layout')
@section ('head')
<head>
    <title> Jsearch | Best Search Engine | Incognito Search Engine</title>
    <meta charset='utf-8'>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!--Follow these guidelines for all canonicalization methods. Cannonical URL
is for SEO. Google hates duplicate pages that don't pass copycape.com, so 
I use re=canonical to indicate the master version/copy of a page -->
    <a href"https://www.e15p3.harvardjoeapps.com"> rel=canonical</a>
</head>
@endsection
