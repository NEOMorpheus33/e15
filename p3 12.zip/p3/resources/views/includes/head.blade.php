@extends main/layout  
@section ('head') 

<meta charset='utf-8'> 
   

    @endsection 