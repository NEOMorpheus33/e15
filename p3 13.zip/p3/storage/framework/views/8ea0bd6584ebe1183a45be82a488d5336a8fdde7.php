  

<link href='style.css' rel='stylesheet'> 

<?php $__env->startSection('addsite'); ?>  

<h1>Add a Site</h1>  

 <p>Add a Website Here for Faster Indexing</p>  

<form method='POST' action='/CRUD/process'> 
    <div class='details'>* Required fields</div>
    <?php echo e(csrf_field()); ?>


    <label for='title'>* Title</label>
    <input type='text' name='title' id='title' value='<?php echo e(old("title")); ?>'> 
    <?php echo $__env->make('includes/error-field', ['fieldName' => 'title'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <label for='url'>* Site URL</label> 
    <div class='details'>

       <p> This is the uniform resource locator for your site's IP  
        <br>It’s suggested that you have a memorable (5-7 characters) URL for Branding & SEO 
         purposes.<em>“an example”</em> would be <em>“JSearch”</em>. 
        which is short, simple, memorable, and has "search" as a related site topic SEO keyword. </p> 
     </div> 

     <label for='url'>* url</label> 
    <input type='url' name='url' id='url' value='<?php echo e(old("url")); ?>'>
    <?php echo $__env->make('includes/error-field', ['fieldName' => 'url'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    

    <label for='description'>* descripton</label> 
    <input type='text' name='description' id='description' value='<?php echo e(old("description")); ?>'>
    <?php echo $__env->make('includes/error-field', ['fieldName' => 'description'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <label for='body'>* Body </label>
    <input type='text' name='body' id='body' value='<?php echo e(old("body")); ?>'>
    <?php echo $__env->make('includes/error-field', ['fieldName' => 'body'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 

    <label for='sitemapxml'>* sitemapxml </label>
    <input type='text' name='sitemapxml' id='sitemapxml' value='<?php echo e(old("sitemapxml")); ?>'>
    <?php echo $__env->make('includes/error-field', ['fieldName' => 'sitemapxml'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 

   

    <button type='submit' class='btn btn-primary'>Add My Site</button>

    <?php if(count($errors) > 0): ?> 
    <div class='alert alert-danger'> 
        Please correct the above errors.
    </div>
    <?php endif; ?>

</form>  

<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/e15/p3/resources/views//CRUD/create.blade.php ENDPATH**/ ?>