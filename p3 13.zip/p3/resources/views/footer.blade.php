@extends('layouts/main') 
@section('footer') 

<html>

<body> 

   <p> Copyright  2021 | Joseph P. Fitzgerald Fanning JPFF | Dr. Buck | Harvard University </P>  
 
 </body> 
 
 </html> 
@endsection 

