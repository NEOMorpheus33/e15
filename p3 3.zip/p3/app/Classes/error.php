
namespace app\Classes\error

<?php 

{ 
    function __construct() { 
        return "search error function was initialized.";
    }

    function create($error) {
        // create search errors 
       
    }
} 

