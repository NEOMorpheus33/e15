<html> 
<body>

Site added! <?php echo $_POST["JoeSearch"]; ?><br>
Your email address is: <?php echo $_POST["title"]; ?>

</body>
</html>