<!-- Author: copyright Joseph Fanning Grad student --> 
<!-- Author: & Susan Buck Professor --> 
<!--  Harvard University -->  

@extends('main') 
@section('content') 
{{$request}}
{{$JoeSearch}} 
{{$error}} 
 @endsection 

