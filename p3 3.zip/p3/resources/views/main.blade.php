<!Doctype html>      
<html lang='en'>   
<head> 
    
    <title> @yield('title') JSearch Better Search for Harvard</title>  
    <meta charset='utf-8'> 
    <link rel="stylesheet" href="style.css"> 
    
    @yield('head') 
</head>  

<body>  

<div class="content">

<a href='/'><img src='/images/JSLogo4.jpg' id='logo' alt='Joe Search Engine Logo Long Version 1.0'> </a>  

 
 <h1>Joe's Harvard Better Results Search Engine</h1>  

    @yield('Search')  

    @yield ('crawled') 

</div> 

    </body> 
    
</html>   




