@extends('main')         
@section('Search')   

/* Author: copyright Joseph Fanning Grad student */
/* Author: & Susan Buck Professor */
/*  Harvard University */


<table class="center"> 
  
 <form action="/process" method="GET">     

  <tr><td><input id="textboxid" type="text" name="JoeSearch" value=" "> </td></tr>   
  <tr><td><label for="text">Type Keywords Search</label></td></tr> 
  
  <tr><td><input type="checkbox" name="PublicSearch" value="already_crawled"> </td></tr>  
  <tr><td><label for="PublicSearch">  Public Search </label></td> </tr>  

  <tr><td><input type="checkbox" name="PrivateSearch" value="already_crawled"> </td></tr> 
  <tr><td><label for="PublicSearch">  Private Search </label></td> </tr>         
  
</table> 

</center>



<h1>Search Engine Results</h1> 
@if($serps) 

    <table border=1> 
        <tr><td>{{$serps->url}} </td></tr>     
        <tr><td>{{$serps->title}} </td></td>   
        <tr><td>{{$serps->description}} </td></tr>  
        <tr><td>{{$serps->body}} </td></tr>  
           
    </table>  

@endif 

@if(!$JoeSearch)
keywords not found. <a href='/main'>Try another search Phrase...</a>
@else

@if(count($errors) > 0)
    <ul class='error'>
        @foreach ($errors->all() as $error)
            <li>{{ $error }}</li>
        @endforeach 
    </ul> 
@endif 

@endsection      





 





