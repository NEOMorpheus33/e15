<!Doctype html>      
<html lang='en'>   
<head> 
    
    <title> <?php echo $__env->yieldContent('title'); ?> JSearch Better Search for Harvard</title>  
    <meta charset='utf-8'> 
    <link rel="stylesheet" href="style.css"> 
    
    <?php echo $__env->yieldContent('head'); ?> 
</head>  

<body>  

<div class="content">

<a href='/'><img src='/images/JSLogo4.jpg' id='logo' alt='Joe Search Engine Logo Long Version 1.0'> </a>  

 
 <h1>Joe's Harvard Better Results Search Engine</h1>  

    <?php echo $__env->yieldContent('Search'); ?>  

    <?php echo $__env->yieldContent('crawled'); ?> 

</div> 

    </body> 
    
</html>   




<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/e15/p3/resources/views/main.blade.php ENDPATH**/ ?>