<footer>
    &copy; Copyright Joseph Paul Fanning 
</footer>