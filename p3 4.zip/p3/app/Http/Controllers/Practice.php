<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Practice extends Controller
{
    //
}
